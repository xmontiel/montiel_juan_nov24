# montiel_juan_nov24

1 Hemos creado el repo
2 Hemos invitado a Luis como colaborador
3 Hemos clonado el repo en local
4 Hemos creado la estructura de carpetas y los archivos
5 Hemos modificado el .gitignore con las dos instrucciones pedidas
6 Hemos creado una rama secundaria llamada JuanMontiel y hemos cambiado a ella
7 Me encuentro escribiendo estas lineas en el README